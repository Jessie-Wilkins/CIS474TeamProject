﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Collections.Specialized;
using System.Text;

namespace WebApplication2
{
    

   
    public class POST_GET
    {
        public void post_data(string url, NameValueCollection data)
        {
            using (var wb = new WebClient())
            {
                
                var response = wb.UploadValues(url, "POST", data);
                string responseInString = Encoding.UTF8.GetString(response);
            }
        }

        public string get_data(string url)
        {
            using (var wb = new WebClient())
            {
                var response = wb.DownloadString(url);
                return response;
            }
        }
       
    }
}