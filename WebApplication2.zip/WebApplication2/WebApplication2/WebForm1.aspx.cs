﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(TextBox2.Text == TextBox3.Text)
            {
                MySQLEnterLogIn mysql_obj = new MySQLEnterLogIn();
                mysql_obj.EnterInfo(TextBox1.Text, TextBox2.Text);
                Div1.InnerHtml = TextBox1.Text + ", welcome to the burger menu!";
            }
            else
            {
                Div1.InnerHtml = "Sorry, your passwords do not match!";
            }
           
        }
    }
}