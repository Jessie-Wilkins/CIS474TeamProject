﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class menu : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                ShoppingCart cart = new ShoppingCart();
                Repeater1.DataSource = cart.getItems();
                Repeater1.DataBind();
                ViewState["cart"] = cart;
            }


        }

        protected void Page_Click(object sender, CommandEventArgs e)
        {


            var myAction = e.CommandName as string;
            var myID = e.CommandArgument.ToString();

            ShoppingCart cart = ViewState["cart"] as ShoppingCart;

            cart.AddToCart(myID);

            Repeater1.DataSource = cart.getItems();
            Repeater1.DataBind();



        }
    }
}