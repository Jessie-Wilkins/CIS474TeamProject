﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace WebApplication2
{
    [Serializable]
    public class ShoppingCart
    {

        List<string> Items = new List<string>();

        public int Quantity { get; set; }

        public System.DateTime DateCreated { get; set; }

        public int OrderId { get; set; }

        public void AddToCart(string item)
        {
            Items.Add(item);
          
            Quantity++;
        }

        public void RemoveFromCart(string item)
        {
            Items.Remove(item);
            Quantity--;
        }

        public List<string> getItems()
        {
            return Items;
        }

    }
}