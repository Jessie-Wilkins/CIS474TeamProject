﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public class MySQLEnterLogIn
    {
        public void EnterInfo(string name, string password)
        {
            DBConnection dbCon = new DBConnection();
            dbCon.DatabaseName = "team_project475";

            if (dbCon.IsConnect())
            {
                //suppose col0 and col1 are defined as VARCHAR in the DB
                string query = string.Format("INSERT INTO customer(username, password) VALUE('{0}', '{1}')", name, password);
                var cmd = new MySqlCommand(query, dbCon.Connection);
                var reader = cmd.ExecuteReader();
                dbCon.Close();
            }

        }
    }
}