﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApplication2;
using System.Web.UI.WebControls;

namespace UnitTestProject1
{
    [TestClass]
    public class menuTesting : menu
    {
        [TestMethod]
        public void PageLoadTest()
        {

            menuTesting item = new menuTesting();

            

        }
    }
}
