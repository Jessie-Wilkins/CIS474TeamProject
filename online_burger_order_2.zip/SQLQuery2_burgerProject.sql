CREATE PROC UserViewByID
@UserID int 
AS
	SELECT *
	FROM user_registration
	Where UserID =@UserID