﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Burger_restraunt_group_project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void allergiesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // this is when the user selects the about option in the menu.
            // this option should provide a message box saying what is this application about.
            MessageBox.Show("This is an application that allows customers to order food online from Bob's Burger.");
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // when exit is selected the application should close.
            Application.Exit();
        }

        private void signUpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // this is when sign up form should open.
            // open sign up form.
            this.IsMdiContainer = true;
            SignUp addStudent = SignUp.getInstance();
            addStudent.MdiParent = this;
            addStudent.Show();
        }

        private void logInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // this is when log in form should open.
            // open log in form.
            this.IsMdiContainer = true;
            LogIn addStudent = LogIn.getInstance();
            addStudent.MdiParent = this;
            addStudent.Show();
        }
    }
}
