﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Burger_restraunt_group_project
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }
        private static SignUp instance;
        public static SignUp getInstance()
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new SignUp();
            }
            else
            {
            }
            return instance;
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // user clicked the exit button.
            // The app should be closed.
            Application.Exit();
        }
    }
}
